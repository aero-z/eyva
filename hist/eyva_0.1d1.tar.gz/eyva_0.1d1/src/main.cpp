#include <curses.h>
#include <stdlib.h>

#include "game.h"

int main(int argc, char** argv) {
	initscr();              // start curses mode


	/* CURSES SETTINGS */

	raw();                  // get the input before ENTER (=> arrow keys)
	noecho();               // don't print input (=> arrow keys)
	keypad(stdscr, true);   // enable F1, F2, ... and arrow keys
	curs_set(0);            // hide the cursor


	/* COLOR */

	if(!has_colors()) {     // check if colors are supported
		endwin();
		printf("ABORTING: Your terminal doesn't seem to support colors.\n");
		return 0;
	}
	start_color();          // enable colors
	use_default_colors();   /* allow transparent background
	                           (we don't need that, but gnome-terminal doesn't
	                           display colors without this option)
	                        */

	/* GAME */

	// property file
	bool ok;
	Game* game = new Game(&ok);
	if(!ok) {
		delete game;
		curs_set(1);
		endwin();
		printf("ABORTING: properties file not found.\n");
		return 1;
	}

	int err;
	if((err = game->init()) != 0) {
		delete game;
		curs_set(1);
		endwin();
		switch(err) {
			case 1:
				printf("ABORTING: map file not found.\n");
				break;
			default:
				printf("ABORTING: unknown error occured.\n");
				break;
		}
		return err;
	}
	while(true) {
		game->inputSequence();
		game->actionSequence();
		if(!game->eventSequence()) {
			delete game;
			break;
		}
	}


	/* EXIT */

	curs_set(1);
	endwin();               // stop curses mode
	return 0;
}

