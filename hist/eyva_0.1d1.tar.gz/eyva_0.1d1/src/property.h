#ifndef _PROPERTY_H_
#define _PROPERTY_H_

#include <cstdio>
#include "lib/ayson.h"

class Property {
	public:
		static bool loadPropertyLibrary();
		static int getType(int);
		static char const* getName(int);
		static char const* getDescription(int);
	private:
		static Ayson* property_library;
};

#endif
