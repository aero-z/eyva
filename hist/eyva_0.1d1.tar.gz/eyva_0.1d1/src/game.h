#ifndef _GAME_H_
#define _GAME_H_

#include <curses.h>
#include <cstdlib> // system calls

// server
#include "entity.h"
#include "property.h"
#include "region.h"
#include "inventory.h"

// client
#include "panel.h"
#include "screen.h"

/*
Maybe someday (in a far future) this class is going to be split up, because...
I HAVE A DREAM:
I wanna make this game working with a Client/Server architecture.
 */

class Game {
	public:
		Game(bool*);
		~Game();
		int init();
		void inputSequence();
		void actionSequence();
		bool eventSequence();

	private:
		bool skip_input_sequence;
		bool skip_action_sequence;
		bool skip_event_sequence;

		int mode;
		int input;

		Entity* player;

		Region* region;
		Screen* screen;
		Panel* panel;
		Inventory* inventory;

		void movePlayer(int);
		void setPlayer(int, int);
		bool isOccupied(int, int);
};

#endif
