#ifndef _PANEL_H_
#define _PANEL_H_

#include <curses.h>
#include "region.h"
#include "entity.h"

class Panel {
	public:
		Panel(Region*);
		void display();
		int interact(int);
	private:
		int input;
		int stateline;
		int messageline;
		int inputline;
		int cursor_pos;
		int panel_width;
		Region* region;
		Entity* player;
		char buffer[81];
		int buffer_size;
		bool checkBuffer(char const*);
		void clearBuffer();
		void deleteFromBuffer(int);
		void insertIntoBuffer(char);
};

#endif
