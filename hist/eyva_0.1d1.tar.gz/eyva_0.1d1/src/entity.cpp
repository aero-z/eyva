#include "entity.h"

/* public methods */

int Entity::createEntity(void) {
	if(number_of_entities < (1<<15)) {
		entity_list[number_of_entities] = new Entity();;
		number_of_entities++;
		return number_of_entities-1;
	} else
		return 0;
}

Entity* Entity::getEntityById(int id) {
	if(id < number_of_entities)
		return entity_list[id];
	else
		return NULL;
}

Entity* Entity::getEntityByPos(int x, int y) {
	for(int i = 0; i < number_of_entities; i++)
		if(entity_list[i]->getXPos() == x && entity_list[i]->getYPos() == y)
			return entity_list[i];
	return NULL;
}

int Entity::getNumberOfEntities(void) {
	return number_of_entities;
}

// Name
char const* Entity::getName(void) {
	return name;
}

void Entity::setName(char const* n) {
	name = n;
}

// Description
char const* Entity::getDescription(void) {
	return description;
}

void Entity::setDescription(char const* d) {
	description = d;
}

// Type
int Entity::getType(void) {
	return type;
}

void Entity::setType(int t) {
	type = t;
}

// Position
void Entity::setPos(int x, int y) {
	pos[0] = x;
	pos[1] = y;
}

int Entity::getXPos(void) {
	return pos[0];
}

int Entity::getYPos(void) {
	return pos[1];
}

// Health
int Entity::getHealth(void) {
	return health;
}

int Entity::getHealthMax(void) {
	return health_max;
}

bool Entity::modHealth(int value) {
	health += value;
	if(health > health_max)
		health = health_max;
	return(health > 0);
}

bool Entity::setHealth(int value) {
	health = value;
	if(health > health_max)
		health = health_max;
	return(health > 0);
}

void Entity::setHealthMax(int value) {
	health_max = value;
}

// Experience
int Entity::getExperience(void) {
	return experience;
}

void Entity::modExperience(int exp) {
	if(experience > 0)
		experience += exp;
}

// Properties
bool Entity::addPropertyId(int id) {
	if(number_of_properties < MAX_PROPERTIES) {
		property_list[number_of_properties] = id;
		number_of_properties++;
		return true;
	} else
		return false;
}

int Entity::removePropertyByIndex(int index) {
	int property_to_remove = property_list[index];
	if(index < number_of_properties && index >= 0) {
		for(int i = index; i < number_of_properties; i++)
			property_list[i] = property_list[i+1];
		return property_to_remove;
	} else
		return -1;
}

int Entity::getPropertyByIndex(int index) {
	if(index < number_of_properties && index >= 0)
		return property_list[index];
	else
		return -1;
}

int Entity::hasPropertyId(int id) {
	for(int i = 0; i < number_of_properties; i++)
		if(property_list[i] == id)
			return i;
	return -1;
}

int Entity::getNumberOfProperties(void) {
	return number_of_properties;
}

/* private methods */

Entity::Entity(void) {
	name        = "[name]";
	description = "[description]";
	pos[0]      = -1;
	pos[1]      = -1;
	type        = 1;
	health      = 0;
	health_max  = 0;
	experience  = 0;
	for(int i = 0; i < MAX_PROPERTIES; i++)
		property_list[i] = -1;
	number_of_properties = 0;
}

// static variables
int Entity::number_of_entities = 0;

Entity* Entity::entity_list[(1<<15)];
