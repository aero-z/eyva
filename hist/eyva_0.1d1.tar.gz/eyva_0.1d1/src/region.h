#ifndef _REGION_H_
#define _REGION_H_

#include <cstdio>

#include "lib/filehandler.h"

#define WIDTH 40
#define HEIGHT 20

class Region {
	public:
		Region();
		int createWorld(char const*);
		int getHeight();
		int getWidth();
		int getSurfaceByPos(int, int);

	private:
		int surface_map[WIDTH][HEIGHT];
		Filehandler mapfile;
};

#endif
