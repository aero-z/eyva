#include "inventory.h"

/* public methods */

Inventory::Inventory(Region* r) {
	region = r;
	for(int y = 0; y < INVENTORY_HEIGHT; y++)
		for(int x = 0; x < INVENTORY_WIDTH; x++) {
			content[y][x] = ' ';
		}
	x_pos = 20;
	y_pos = 1;
	marked_line = 0;

	// define colors
	#include "lib/colortable.h"
	
	clearContent();
}

void Inventory::setCarrier(Entity* c) {
	carrier = c;
	if(Entity::getEntityById(0) == c)
		exit_key = 'b';
	else
		exit_key = 27;

	clearContent();

	for(int y = 0; y < carrier->getNumberOfProperties() && y < INVENTORY_HEIGHT;
			y++)
		for(int x = 0; x < INVENTORY_WIDTH; x++) {
			content[y][x] =
					Property::getName(carrier->getPropertyByIndex(y))[x];
			if(content[y][x] == 0 || content[y][x] == 10) {
				content[y][x] = ' ';
				break;
			}
		}
}

bool Inventory::interact(int input) {
	switch(input) {
		case 27:
		case 'b':
		//case exit_key: // why, oh why???
			return false;
		case 259: // move up
		case 'k':
			if(marked_line > 0)
				marked_line--;
			break;
		case 258: // move down
		case 'j':
			if(marked_line < carrier->getNumberOfProperties()-1)
				marked_line++;
			break;
	}
	for(int y = 0; y < INVENTORY_HEIGHT; y++)
		for(int x = 0; x < INVENTORY_WIDTH; x++)
			drawPixel(y, x);
	return true;
}

/* private methods */

void Inventory::drawPixel(int y, int x) {
	if(y == marked_line)
		color_code = 3;
	else
		color_code = 30;
	attron(COLOR_PAIR(color_code));
	mvaddch(y+y_pos, x+x_pos, content[y][x]);
	attroff(COLOR_PAIR(color_code));
}

void Inventory::clearContent(void) {
	for(int y = 0; y < INVENTORY_HEIGHT; y++)
		for(int x = 0; x < INVENTORY_WIDTH; x++)
			content[y][x] = ' ';
}

