#include "filehandler.h"

#include <cstdlib>

Filehandler::Filehandler(void) {
	for(int row = 0; row < MAX_ROWS; row++) {
		for(int col = 0; col < 80; col++) {
			content[row][col] = ' ';
		}
	}

	for(int i = 0; i < 80*MAX_ROWS; i++)
		pure_content[i] = 0;
}

bool Filehandler::loadFile(char const* filepath) {
	// open file
	if((file = fopen(filepath, "r")) == NULL)
		return false;
	
	// copy content into buffer and close file
	for(int i = 0; !feof(file) && i < 80*MAX_ROWS; i++) {
		pure_content[i] = fgetc(file);
	}
	fclose(file);

	// format and store buffer into content
	int row = 0;
	int col = 0;
	for(int i = 0; row < MAX_ROWS && pure_content[i] != 0; i++, col++) {
		if(pure_content[i] == 10) {
			col = -1;
			row++;
		} else if(col < 80)
			content[row][col] = pure_content[i];
	}
	number_of_rows = row;
	return true;
}

char Filehandler::getContent(int row, int col) {
	return content[row][col];
}

int Filehandler::getNumberOfRows(void) {
	return number_of_rows;
}

char Filehandler::getPureContent(int index) {
	if(index >= 80*MAX_ROWS) index = 80*MAX_ROWS-1;
	return pure_content[index];
}
