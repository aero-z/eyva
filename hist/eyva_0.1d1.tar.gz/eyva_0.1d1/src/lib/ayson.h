#ifndef _AYSON_H_
#define _AYSON_H_

#include <cstdio>

#define BUFFER_LENGTH 256

class Ayson {
	public:
		Ayson();
		bool setFile(char const*);
		int getType(int);
		char const* getName(int);
		char const* getDescription(int);
	private:
		char filename[BUFFER_LENGTH];
		char buffer[BUFFER_LENGTH];
		void clearBuffer();
};

#endif
