#ifndef _FILEHANDLER_H_
#define _FILEHANDLER_H_

#include <cstdio>

#define MAX_ROWS 1024

class Filehandler {
	public:
		Filehandler();
		bool loadFile(char const*);
		char getContent(int, int);
		char getPureContent(int);
		int getNumberOfRows();
	private:
		FILE* file;
		char content[MAX_ROWS][80];
		char pure_content[80*MAX_ROWS];
		int number_of_rows;
};

#endif
