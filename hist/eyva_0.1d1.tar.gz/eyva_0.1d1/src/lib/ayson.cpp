#include "ayson.h"

Ayson::Ayson(void) {
	clearBuffer();
}

bool Ayson::setFile(char const* f) {
	clearBuffer();
	for(int i = 0; (filename[i] = f[i]) != 0; i++);

	FILE* file;
	if((file = fopen(filename, "r")) == NULL)
		return false;
	fclose(file);
	return true;
}

int Ayson::getType(int id) {
	clearBuffer();
	FILE* file;
	int type = -1;

	if((file = fopen(filename, "r")) == NULL)
		return -1;
	
	while(!feof(file)) {
		fgets(buffer, BUFFER_LENGTH, file);
		if(buffer[0] == '.') {  // if the line starts a new property, go on
			fgets(buffer, BUFFER_LENGTH, file);
				
			// if the ID is alright, store the type and stop the loop
			if(1000*(buffer[1]-48) + 100*(buffer[2]-48)
					+ 10*(buffer[3]-48) + (buffer[4]-48) == id) {
				type = buffer[0]-48;
				break;
			}
		}
	}

	fclose(file);
	return type;
}

char const* Ayson::getName(int id) {
	FILE* file;

	if((file = fopen(filename, "r")) == NULL)
		return 0;
	
	while(!feof(file)) {
		fgets(buffer, BUFFER_LENGTH, file);
		if(buffer[0] == '.') {  // if the line starts a new property, go on
			fgets(buffer, BUFFER_LENGTH, file);
				
			// if the ID is alright, store the next line and stop the loop
			if(1000*(buffer[1]-48) + 100*(buffer[2]-48)
					+ 10*(buffer[3]-48) + (buffer[4]-48) == id) {
				fgets(buffer, BUFFER_LENGTH, file);
				break;
			}
		}
	}

	fclose(file);
	return buffer;
}

char const* Ayson::getDescription(int id) {
	clearBuffer();
	FILE* file;

	if((file = fopen(filename, "r")) == NULL)
		return 0;
	
	while(!feof(file)) {
		fgets(buffer, BUFFER_LENGTH, file);
		if(buffer[0] == '.') {  // if the line starts a new property, go on
			fgets(buffer, BUFFER_LENGTH, file);
				
			// if the ID is alright, store the uppernext line and stop the loop
			if(1000*(buffer[1]-48) + 100*(buffer[2]-48)
					+ 10*(buffer[3]-48) + (buffer[4]-48) == id) {
				fgets(buffer, BUFFER_LENGTH, file);
				fgets(buffer, BUFFER_LENGTH, file);
				break;
			}
		}
	}

	fclose(file);
	return buffer;
}

void Ayson::clearBuffer(void) {
	for(int i = 0; i < BUFFER_LENGTH; i++)
		buffer[i] = 0;
}

