#include "region.h"

/* public methods */

Region::Region(void) {
	for(int x = 0; x < WIDTH; x++)
		for(int y = 0; y < HEIGHT; y++)
			surface_map[x][y] = 0; // default (nothing)
}

int Region::createWorld(char const* filename) {
	char mapfile_path[128];
	sprintf(mapfile_path, "resources/maps/%s.map", filename);

	if(!mapfile.loadFile(mapfile_path))
		return 1; // file not found

	int type;
	for(int y = 0; y < HEIGHT; y++) {
		for(int x = 0; x < WIDTH; x++) {
			switch(mapfile.getContent(y, x)) {
				case '|': // vertical wall
					type = 1;
					break;
				case '-': // horizontal wall
					type = 2;
					break;
				case '+': // crossing walls
					type = 3;
					break;
				case 'W': // water
					type = 5;
					break;
				case 'w': // water at the edge
					type = 6;
					break;
				case 92: // ladder downwards (backslash)
					type = 8;
					break;
				case '/': // ladder upwards
					type = 9;
					break;
				case '.': // grass
					type = 10;
					break;
				default: // nothing
					type = 0;
					break;
			}
			surface_map[x][y] = type;
		}
	}
	return 0;
}

int Region::getWidth(void) {
	return(WIDTH);
}

int Region::getHeight(void) {
	return(HEIGHT);
}

int Region::getSurfaceByPos(int x, int y) {
	if(x >= WIDTH)  x = WIDTH-1;
	if(x < 0)       x = 0;
	if(y >= HEIGHT) y = HEIGHT-1;
	if(y < 0)       y = 0;

	return surface_map[x][y];
}

