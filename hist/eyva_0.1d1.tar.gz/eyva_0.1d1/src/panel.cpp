#include "panel.h"

/* public methods */

Panel::Panel(Region* r) {
	region = r;
	player = Entity::getEntityById(0);

	panel_width = 2*region->getWidth();         // define panel width
	clearBuffer();                              // clear buffer

	stateline = region->getHeight()-1 + 1;      // define information area
	messageline = stateline + 1;                // define message output area
	inputline = stateline + 3;                  // define command input area

	#include "lib/colortable.h"                 // define colors
}

void Panel::display(void) {
	// name
	mvaddstr(stateline, 0, player->getName());

	// bag content
	char bag_string[11];
	sprintf(bag_string, "bag: %2d/%2d", player->getNumberOfProperties(),
			MAX_PROPERTIES);
	mvaddstr(stateline, 20, bag_string);
}

int Panel::interact(int in) {
	input = in;
	int nextmode = 1;

	// see what's up
	switch(input) {
		case 10: // enter
			if(checkBuffer(":exit") || checkBuffer(":q")) {
				nextmode = 3;
			} else if(checkBuffer(":save") || checkBuffer(":w")) {
				nextmode = 4;
			} else if(checkBuffer(":bag")) {
				nextmode = 5;
			} else {
				nextmode = 0;
			}
			clearBuffer();
			break;
		case 27: // escape
			clearBuffer();
			nextmode = 0;
		case 127: // backspace
		case 263: // backspace in virtual terminal
			if(buffer_size > 0) {
				if(cursor_pos > 0) {
					deleteFromBuffer(cursor_pos-1);
					cursor_pos--;
					move(inputline, cursor_pos);
				}
			}
			if(buffer_size == 0)
				nextmode = 0;
			break;
		case 330: // delete
			if(buffer_size > 0) {
				if(cursor_pos < buffer_size)
					deleteFromBuffer(cursor_pos);
			}
			if(buffer_size == 0)
				nextmode = 0;
			break;
		case 261: // right
			if(cursor_pos < buffer_size) {
				cursor_pos++;
				move(inputline, cursor_pos);
			}
			break;
		case 260: // left
			if(cursor_pos > 0) {
				cursor_pos--;
				move(inputline, cursor_pos);
			}
			break;
		case 259: // up
			// history
			break;
		case 258: // down
			// history
			break;

		/* if none of the above applied, it's probably save to assume that it's
		   a simple letter.
		 */
		default:
			insertIntoBuffer(input);
			move(inputline, cursor_pos);
			break;
	}

	// print current buffer
	for(int i = 0; i < panel_width; i++) {
		mvaddch(inputline, i, buffer[i]);
	}

	// set cursor
	move(inputline, cursor_pos);

	return nextmode;
}

/* private methods */

bool Panel::checkBuffer(char const* c) {
	int c_length = 0;
	for(int i = 0; i < panel_width && c[i] != 0; i++) {
		c_length = i+1;
	}
	
	if(c_length != buffer_size)
		return false;

	for(int i = 0; i < c_length; i++) {
		if(buffer[i] != c[i])
			return false;
	}
	return true;
}

void Panel::clearBuffer(void) {
	for(int i = 0; i < panel_width+1; i++)
		buffer[i] = ' ';
	buffer_size = 0;
	cursor_pos = 0;
}

void Panel::deleteFromBuffer(int position) {
	for(int i = position; i < panel_width; i++)
		buffer[i] = buffer[i+1];
	buffer_size--;
}

void Panel::insertIntoBuffer(char character) {
	if(buffer_size < panel_width) {
		for(int i = panel_width-1; i > cursor_pos; i--)
			buffer[i] = buffer[i-1];
		buffer[cursor_pos] = character;
		buffer_size++;
		cursor_pos++;
	}
}
