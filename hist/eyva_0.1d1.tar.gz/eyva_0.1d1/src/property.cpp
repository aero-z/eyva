#include "property.h"

/* public methods */

bool Property::loadPropertyLibrary(void) {
	property_library = new Ayson();
	return property_library->setFile("resources/properties");
}

int Property::getType(int id) {
	return property_library->getType(id);
}

char const* Property::getName(int id) {
	return property_library->getName(id);
}

char const* Property::getDescription(int id) {
	return property_library->getDescription(id);
}

/* private methods */

Ayson* Property::property_library;
