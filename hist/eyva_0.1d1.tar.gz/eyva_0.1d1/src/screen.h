#ifndef _SCREEN_H_
#define _SCREEN_H_

#include "region.h"
#include "entity.h"

class Screen {
	public:
		Screen(Region*);
		void draw();
	private:
		Region* region;
		Entity* player;
		int background_color;
		int foreground_color;
		char const* ascii;
		void drawPixel(int, int);
		void drawSubPixel(int, int, char);
};

#endif
