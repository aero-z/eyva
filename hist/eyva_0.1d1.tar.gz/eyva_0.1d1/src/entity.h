#ifndef _ENTITY_H_
#define _ENTITY_H_

#include <cstdio>
#include "property.h"

#define MAX_PROPERTIES 10

class Entity {
	public:
		static int createEntity();
		static Entity* getEntityById(int);
		static Entity* getEntityByPos(int, int);
		static int getNumberOfEntities();

		char const* getName();
		void setName(char const*);

		char const* getDescription();
		void setDescription(char const*);

		int getType();
		void setType(int);

		int getXPos();
		int getYPos();
		void setPos(int, int);

		int getHealth();
		int getHealthMax();
		bool modHealth(int);
		bool setHealth(int);
		void setHealthMax(int);

		int getExperience();
		void modExperience(int);

		bool addPropertyId(int);
		int removePropertyByIndex(int);
		int getPropertyByIndex(int);
		int hasPropertyId(int);
		int getNumberOfProperties();

	private:
		Entity();
		static Entity* entity_list[(1<<15)];
		static int number_of_entities;

		char const* name;
		char const* description;
		int type;
		int pos[2];
		int health;
		int health_max;
		int experience;
		int property_list[MAX_PROPERTIES];
		int number_of_properties;
};

#endif
