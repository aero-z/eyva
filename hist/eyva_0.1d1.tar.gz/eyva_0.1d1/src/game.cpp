#include "game.h"

/* public methods */

Game::Game(bool* return_value) {
	if(Property::loadPropertyLibrary()) {
		*return_value = true;
	} else
		*return_value = false;

	Entity::createEntity();
	player = Entity::getEntityById(0);
	player->setName("Eriya");
	player->addPropertyId(1); // let him swim!
	player->addPropertyId(2); // let him cut trees!
	player->addPropertyId(3); // let him heal!
	
	region = new Region();
	screen = new Screen(region);
	panel = new Panel(region);
	inventory = new Inventory(region);
	inventory->setCarrier(player);

}

Game::~Game(void) {
	delete region;
	delete screen;
	delete panel;
	delete inventory;
}

int Game::init(void) {
	int err;
	if((err = region->createWorld("001")) != 0) {
		return err;
	}

	Entity::createEntity();
	Entity::getEntityById(1)->addPropertyId(2);
	Entity::getEntityById(1)->setPos(4, 3);

	skip_input_sequence = false;
	skip_action_sequence = false;
	skip_event_sequence = false;

	mode = 0;           /* set mode
	                       0: ingame mode
	                       1: command mode
	                       2: interaction mode
	                       3: sytem mode EXIT
	                     */

	// set player position
	player->setPos(1,3);
	
	screen->draw();
	panel->display();
	return 0;
}

void Game::inputSequence(void) {
	if(skip_input_sequence) {
		skip_input_sequence = false;
	} else {
		input = getch();
		switch(mode) {

			// INGAME MODE
			case 0:
				switch(input) {
					case ':': // -> command mode
						mode = 1;
						break;
					case 'b': // -> bag mode
						mode = 5;
						input = ' '; /* take away the input key, otherwise the
						                bag disappears */
						break;
				}
				break;

			// COMMAND MODE
			case 1:
				// nothing (yet)
				break;

			// INTERACTION MODE
			case 2:
				// nothing (yet)
				break;

			// EXIT MODE
			case 3:
				// nothing (yet)
				break;

			// SAVE MODE
			case 4:
				mode = 0;
				break;

			// BAG MODE
			case 5:
				switch(input) {
					case 'b': // -> ingame mode
						mode = 0;
						break;
				}
				break;
		}
	}
}

void Game::actionSequence() {
	if(skip_action_sequence) {
		skip_action_sequence = false;
	} else {
		switch(mode) {
			
			// INGAME MODE
			case 0:
				switch(input) {
					case 259: // move up
					case 'k':
					case 'w':
						movePlayer(0);
						break;
					case 261: // move right
					case 'l':
					case 'd':
						movePlayer(1);
						break;
					case 258: // move down
					case 'j':
					case 's':
						movePlayer(2);
						break;
					case 260: // move left
					case 'h':
					case 'a':
						movePlayer(3);
						break;
					case ' ': // interact with entity
						if(isOccupied(player->getXPos(), player->getYPos()));
							// TODO
						break;
				}
				screen->draw();
				panel->display();
				break;

			// COMMAND MODE
			case 1:
				screen->draw();
				panel->display();
				mode = panel->interact(input);
				// toggle cursor visibility depending on the mode
				if(mode == 1)
					curs_set(1);
				else
					curs_set(0);
				if(mode == 5)
					skip_input_sequence = true;
				break;

			// INTERACTION MODE
			case 2:
				break;

			// EXIT MODE
			case 3:
				break;

			// SAVE MODE
			case 4:
				break;

			// BAG MODE
			case 5:
				if(!inventory->interact(input)) {
					skip_input_sequence = true;
					mode = 0;
				}
				break;
		}
	}
}

bool Game::eventSequence() {
	if(skip_event_sequence) {
		skip_event_sequence = false;
	} else {
		switch(mode) {

			// INGAME MODE
			case 0:
				// TODO
				break;

			// COMMAND MODE
			case 1:
				// TODO
				break;

			// INTERACTION MODE
				// TODO
				break;

			// EXIT MODE
			case 3:
				return false;

			// SAVE MODE
			case 4:
				// TODO
				break;
		}
	}
	return true;
}

/* private methods */

void Game::movePlayer(int direction) {
	switch(direction) {
		case 0: // up
			setPlayer(player->getXPos(), player->getYPos()-1);
			break;
		case 1: // right
			setPlayer(player->getXPos()+1, player->getYPos());
			break;
		case 2: // down
			setPlayer(player->getXPos(), player->getYPos()+1);
			break;
		case 3: // left
			setPlayer(player->getXPos()-1, player->getYPos());
			break;
	}
}

void Game::setPlayer(int x, int y) {
	switch(region->getSurfaceByPos(x, y)) {
		case 1: // walls
		case 2:
		case 3:
			break;
		case 5: // water
			if(player->hasPropertyId(1) != -1)
				player->setPos(x, y);
			break;
		default:
			player->setPos(x, y);
			break;
	}
}

bool Game::isOccupied(int x, int y) {
	return(Entity::getEntityByPos(x, y) != NULL);
}
