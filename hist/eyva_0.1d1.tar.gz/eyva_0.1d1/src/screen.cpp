#include "screen.h"

#include <curses.h>

/* public methods */

Screen::Screen(Region* r) {
	region = r;
	player = Entity::getEntityById(0);

	// define colors
	#include "lib/colortable.h"
}

void Screen::draw(void) {
	for(int x = 0; x < region->getWidth(); x++) {
		for(int y = 0; y < region->getHeight(); y++) {
			background_color = 0; // default: black
			foreground_color = 7; // default: white
			ascii = "  ";         // default: empty

			// planet
			switch(region->getSurfaceByPos(x, y)) {
				case 1: // vertical wall
					foreground_color = 2;
					ascii = "| ";
					break;
				case 2: // horizontal wall
					foreground_color = 2;
					if(x < region->getWidth()-1
							&& (region->getSurfaceByPos(x+1, y) == 2
							|| region->getSurfaceByPos(x+1, y) == 3))
						ascii = "--";
					else
						ascii = "- ";
					break;
				case 3: // crossing wall
					foreground_color = 2;
					if(x < region->getWidth()-1
							&& (region->getSurfaceByPos(x+1, y) == 2
							|| region->getSurfaceByPos(x+1, y) == 3))
						ascii = "+-";
					else
						ascii = "+ ";
					break;
				case 5: // water
					background_color = 4; // blue
					drawSubPixel(x-1, y, ' ');
					break;
				case 8: // ladder downwards
					foreground_color = 1; // red
					ascii = "\\ ";
					break;
				case 9: // ladder upwards
					foreground_color = 1; // red
					ascii = "/ ";
					break;
				case 10: // grass
					foreground_color = 2; // green
					ascii = ". ";
					break;
			}

			// crowd
			if(player->getXPos() == x
					&& player->getYPos() == y) {
				foreground_color = 7; // white
				ascii = "@ ";
			} else if(Entity::getEntityByPos(x, y) != NULL) {
				switch(Entity::getEntityByPos(x, y)->getType()) {
					default:
						foreground_color = 3; // yellow
						ascii = "o ";
						break;
				}
			}

			// ... and finally: draw it!
			drawPixel(x, y);
		}
	}
}

/* private methods */

void Screen::drawPixel(int x, int y) {
	attron(COLOR_PAIR(10*background_color + foreground_color));
	mvaddstr(y, 2*x, ascii);
	attroff(COLOR_PAIR(10*background_color + foreground_color));
}

// ugly hack
void Screen::drawSubPixel(int x, int y, char c) {
	attron(COLOR_PAIR(10*background_color + foreground_color));
	mvaddch(y, 2*x+1, c);
	attroff(COLOR_PAIR(10*background_color + foreground_color));
}
