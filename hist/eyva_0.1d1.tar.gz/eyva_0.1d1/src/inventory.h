#ifndef _INVENTORY_H_
#define _INVENTORY_H_

#include "entity.h"
#include "region.h"

#include <curses.h>

#define INVENTORY_WIDTH 30
#define INVENTORY_HEIGHT 10

class Inventory {
	public:
		Inventory(Region*);
		void setCarrier(Entity*);
		bool interact(int);
	private:
		int x_pos, y_pos;
		void drawPixel(int, int);
		void clearContent();
		int exit_key;
		char content[INVENTORY_HEIGHT][INVENTORY_WIDTH];
		int marked_line;
		int color_code;
		Entity* carrier;
		Region* region;
};

#endif
